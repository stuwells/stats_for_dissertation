#This intro was largely based on "An introduction to dplR" by Andy Bunn and Mikko Korpela
#https://cran.r-project.org/web/packages/dplR/vignettes/intro-dplR.pdf

#*****1. FIRST STEPS:
#*****
#*****

#Load dplR

library(dplR)

#Set the working directory if not there already

setwd("~/R/dendro")

#Read the data into R; this is one example

cana434 <- read.rwl(fname="cana434.rwl", header = TRUE, format=c("tucson"))

#This is another example showing that you don't have to be verbose

cwn1t1b <- read.rwl(fname="CWN-1-01B-Untitled-Untitled.rwl")

#You should make sure the file looks ready to process
#Colnames will tell you how many tree-ring series are in the file

colnames(cana434)
colnames(cwn1t1b)

#You can get basic stats here; average length, timespan, mean series intercorrelation, etc.
#This also tells you if you are missing rings, but you need several series within the same file for this.

rwl.report(cana434)

#If you try to run this on a single series it will complain that it can't compare using only one series; expect an error

rwl.report(cwn1t1b)

#The function 'summary' is another way to get descriptive statistics
#Both rwl.report and summary give an AR1 value; this will be used soon

summary(cwn1t1b)
summary(cana434)

#The function rwl.stats seems to be the same as the function 'summary.'  
#You can also specify the number of rows, as here with 1-10, to keep it short

rwl.stats(cana434[1:10])

#Next, let's plot the data; "spag" indicates a spaghetti plot rather than straight lines
#Specifically, this shows variability in tree-ring width over time
#Know that this depiction does not have the autocorrelation taken out and displays very raw data.

plot(cana434, plot.type = "spag")

#This will also work on single series of course

plot(cwn1t1b, plot.type = "spag")


#*****2. DETRENDING:
#*****
#*****

#Now we will produce a .rwi file (index) which is the result of dividing the raw widths against your chosen growth model
#All index series should by definition have a mean of 1
#We will use the standard 'detrend' function but also see cms, rcs, bai.in, and bai.out
#Detrending by fitting a negative exponential curve is the most common approach.

cana434.rwi <- detrend(rwl = cana434, method = "ModNegExp")
cwn1t1b.rwi <- detrend(rwl = cwn1t1b, method = "ModNegExp")

#You could also do it with other methods by calling, "Spline", "Mean", "Ar", "Friedman", or "ModHugershoff"
#You could also do this on individual series and choose to use different detrending methods even within the same series file using i.detrend
#The function detrend.series puts you in verbose mode, but then it will require a lot more from you.
#It will complain at you if you have N/A listed under any years, as can happen when you extract it from the combined series rwl file.


#*****3. CHECKING YOUR DATA AGAIN
#*****
#*****

#If you have several cores from the same tree, you can see how much agreement there is between them as below
#The function 'read.ids' tells which trees have multiple cores
#Then you can have it display the stats describing within tree vs. between tree correlations.
#In general dendrochronologists are interested in the rbar.tot and SNR (signal-to-noise ratio) numbers

cana434.ids <- read.ids(cana434, stc = c(3,2,3))
print(cana434.ids)
rwi.stats(cana434.rwi, cana434.ids, prewhiten=TRUE)

#Another way to show interseries correlation is through the function 'interseries.cor'
#This will give you the "overall interseries correlation" which tends to be higher than rbar.tot
#This is done by constructing a master chronology and then comparing everything else against it

cana434.rho <- interseries.cor(cana434.rwi, prewhiten = TRUE, method = "spearman")

#Show the first ten values unless you want to see it all right now in order to check for abberant series

cana434.rho[1:10,]

#Get the mean interseries correlation

mean(cana434.rho[,1])

#*****4. BUILDING A MASTER CHRONOLOGY
#*****
#*****

#Using Tukey’s biweight robust mean we will average across our detrended series to build a master chronology
#You can specify the prefix, such as the "p" in the example here
#You should mess with the nyrs number until it has the spline fit you want

cana434.crn <- chron(cana434.rwi, prefix ="p")
plot(cana434.crn, add.spline=TRUE, nyrs=20)

#Here is a very silly example of making a master chronology from just one series.  It's really just finding the average of itself.
#However I have included it so that you can see the grey bar showing sample depth is consistent across the whole timeframe shown
#If you look at the cana434 master chronology, the grey area will actually show the variation in sample depth

cwn1t1b.crn <- chron(cwn1t1b.rwi)
plot(cwn1t1b.crn, add.spline=TRUE, nyrs=20)

#When you are comfortable with this, go back to the original Intro to dplR in R and try the example in pages 13-15
#This will show where the environmental signal grows weak and show what it would be like to chop off the weak part of your data
