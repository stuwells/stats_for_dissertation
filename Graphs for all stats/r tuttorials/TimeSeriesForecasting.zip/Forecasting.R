# Time Series Forecasting and Data Manipulation
# By Trevor McKellar 5/6/19

# Attached Libraries
library(SPEI)
library(SCI)

# set working directory 
#setwd("/Users/Trevor1/Desktop/PhD Research/LC_Data")                               #Mac
setwd("C:/Users/tmcke/Desktop/Graduate Spring 2019/ENVS696A/Forecasting Project/")  #Windows 

# Read in Forecasting Dataset and create new Date, Day, Month, Year Columns (for later aggregate)
Forecast<-read.table("Forecasting Data.txt",skip=1, fill=TRUE)
Forecast$date2<-seq(as.Date("1979/1/1"), as.Date("2018/10/31"), "days") #Create new date column as sequence (helps with plotting)
Forecast$day<-as.numeric(format(as.Date(Forecast$date), "%j"))
Forecast$month<-as.numeric(format(as.Date(Forecast$date), "%m"))
Forecast$year<-as.numeric(format(as.Date(Forecast$date), "%Y"))
Forecast<-Forecast[-c(1:1)] # Remove first date column (no longer needed)
colnames(Forecast)<-c("Precip","Soil_Moisture_10cm","Soil_Moisture_30cm","Soil_Moisture_50cm","Date1","Day","Month","Year")



# Plot Time Series and Correlation Plots of Data
par(mfrow=c(1,2))
plot(Forecast$Date1,Forecast$Precip,type="l",col="dark blue",xlab="Time",ylab="Precip cm",main="Daily Precipitation")
plot(Forecast$Date1,Forecast$Soil_Moisture_10cm,type="l",lwd=2,col="black",xlab="Time",ylab="Soil Moisture",main="Daily Soil Moisture")
lines(Forecast$Date1,Forecast$Soil_Moisture_30cm,type="l",lwd=2,col="red")
lines(Forecast$Date1,Forecast$Soil_Moisture_50cm,type='l',lwd=2,col="green")

par(mfrow=c(1,3))
lm1<-lm(Forecast$Soil_Moisture_10cm ~ Forecast$Precip)
plot(Forecast$Precip,Forecast$Soil_Moisture_10cm,col="blue",xlab="Precip",ylab="10cm Soil Moisture",
    main=c(paste('Cor=',round(cor(Forecast$Precip,Forecast$Soil_Moisture_10cm),2),", r^2=",round(summary(lm1)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm1, col="red", lwd=1)
lm2<-lm(Forecast$Soil_Moisture_30cm ~ Forecast$Precip)
plot(Forecast$Precip,Forecast$Soil_Moisture_30cm,col="blue",xlab="Precip",ylab="30cm Soil Moisture",
     main=c(paste('Cor=',round(cor(Forecast$Precip,Forecast$Soil_Moisture_30cm),2),", r^2=",round(summary(lm2)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm2, col="red", lwd=1)
lm3<-lm(Forecast$Soil_Moisture_50cm ~ Forecast$Precip)
plot(Forecast$Precip,Forecast$Soil_Moisture_50cm,col="blue",xlab="Precip",ylab="50cm Soil Moisture",
     main=c(paste('Cor=',round(cor(Forecast$Precip,Forecast$Soil_Moisture_50cm),2),", r^2=",round(summary(lm3)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm3, col="red", lwd=1)

cor.test(Forecast$Precip,Forecast$Soil_Moisture_10cm, method="pearson")


# Convert Data From Daily to Monthly using "Pivot Tables" (aggregate function)
pivot1<-aggregate(Precip ~ Month + Year,Forecast,sum)                 # sum monthly precip (cm)
pivot2<-aggregate(Soil_Moisture_10cm ~ Month + Year,Forecast,mean)    # average monthly soil moisture at z depth
pivot3<-aggregate(Soil_Moisture_30cm ~ Month + Year,Forecast,mean)    # ^^^
pivot4<-aggregate(Soil_Moisture_50cm ~ Month + Year,Forecast,mean)    # ^^^
pivot5<-aggregate(Date1 ~ Month + Year,Forecast,last)                  # select last day of month



# Create New Data Table with Monthly Data
ForecastMonth<-data.frame(pivot5$Date1,pivot1$Month,pivot1$Year,pivot1$Precip,pivot2$Soil_Moisture_10cm,pivot3$Soil_Moisture_30cm,pivot4$Soil_Moisture_50cm)
colnames(ForecastMonth)<-c("Date3","Month","Year","MoSum_Precip","MoAvg_SM10cm","MoAvg_SM30cm","MoAvg_SM50cm")



# Plot Time Series and Correlation Plots of Monthly Data
par(mfrow=c(1,2))
plot(ForecastMonth$Date3,ForecastMonth$MoSum_Precip,type="l",col="dark blue",xlab="Time",ylab="Total Precip cm",main="Monthly Total Precipitation")
plot(ForecastMonth$Date3,ForecastMonth$MoAvg_SM10cm,type="l",lwd=2,col="black",xlab="Time",ylab="Average Soil Moisture",main="Monthly Average Soil Moisture")
lines(ForecastMonth$Date3,ForecastMonth$MoAvg_SM30cm,type="l",lwd=2,col="red")
lines(ForecastMonth$Date3,ForecastMonth$MoAvg_SM50cm,type='l',lwd=2,col="green")

par(mfrow=c(1,3))
lm1<-lm(ForecastMonth$MoAvg_SM10cm ~ ForecastMonth$MoSum_Precip)
plot(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM10cm,col="blue",xlab="Precip",ylab="10cm Soil Moisture",
     main=c(paste('Cor=',round(cor(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM10cm),2),", r^2=",round(summary(lm1)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm1, col="red", lwd=1)
lm2<-lm(ForecastMonth$MoAvg_SM30cm ~ ForecastMonth$MoSum_Precip)
plot(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM30cm,col="blue",xlab="Precip",ylab="30cm Soil Moisture",
     main=c(paste('Cor=',round(cor(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM30cm),2),", r^2=",round(summary(lm2)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm2, col="red", lwd=1)
lm3<-lm(ForecastMonth$MoAvg_SM50cm ~ ForecastMonth$MoSum_Precip)
plot(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM50cm,col="blue",xlab="Precip",ylab="50cm Soil Moisture",
     main=c(paste('Cor=',round(cor(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM50cm),2),", r^2=",round(summary(lm3)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm3, col="red", lwd=1)

cor.test(ForecastMonth$MoSum_Precip,ForecastMonth$MoAvg_SM10cm, method="pearson")



# Convert Monthly Data to standard distribution using SPEI and SCI packages (i.e. index precip and soil moisture)
PS=2      # Time scale("window") for precipitation time series (aggragates "PS" number of months to compare with soil moisture; i.e 2 = sum precip from Jan + Feb)
NormPrecip<-spi(ts(ForecastMonth$MoSum_Precip,freq=12,start=c(1979,1)),PS,distribution='Gamma',fit='ub-pwm') 

dum1<-fitSCI(ForecastMonth$MoAvg_SM10cm,first.mon=1,time.scale=1,distr="genlog",p0=FALSE,start.fun.fix=TRUE)
dum2<-transformSCI(ForecastMonth$MoAvg_SM10cm,first.mon=1,obj=dum1,sci.limit=3)
NormSM10cm<-data.frame(fitted=dum2)

dum1<-fitSCI(ForecastMonth$MoAvg_SM30cm,first.mon=1,time.scale=1,distr="genlog",p0=FALSE,start.fun.fix=TRUE)
dum2<-transformSCI(ForecastMonth$MoAvg_SM30cm,first.mon=1,obj=dum1,sci.limit=3)
NormSM30cm<-data.frame(fitted=dum2)

dum1<-fitSCI(ForecastMonth$MoAvg_SM50cm,first.mon=1,time.scale=1,distr="genlog",p0=FALSE,start.fun.fix=TRUE)
dum2<-transformSCI(ForecastMonth$MoAvg_SM50cm,first.mon=1,obj=dum1,sci.limit=3)
NormSM50cm<-data.frame(fitted=dum2)



# Plot new normailzed time series and correlation plots of precip and soil moiture
par(mfrow=c(2,1))
plot(ForecastMonth$Date3,NormPrecip$fitted,type="l",col="dark blue",ylim=c(-3,3),xlab="Time",ylab="Total Precip cm",main="Monthly Total Precipitation")
plot(ForecastMonth$Date3,NormSM10cm$fitted,type="l",lwd=2,col="black",ylim=c(-3,3),xlab="Time",ylab="Average Soil Moisture",main="Monthly Average Soil Moisture")
lines(ForecastMonth$Date3,NormSM30cm$fitted,type="l",lwd=2,col="red")
lines(ForecastMonth$Date3,NormSM50cm$fitted,type='l',lwd=2,col="green")

par(mfrow=c(1,3))
lm1<-lm(NormSM10cm$fitted ~ NormPrecip$fitted)
plot(NormPrecip$fitted,NormSM10cm$fitted,col="blue",xlab="Precip",ylab="10cm Soil Moisture",
     main=c(paste('Cor=',round(cor(NormPrecip$fitted,NormSM10cm$fitted,use="complete.obs"),2),", r^2=",round(summary(lm1)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm1, col="red", lwd=1)
lm2<-lm(NormSM30cm$fitted ~ NormPrecip$fitted)
plot(NormPrecip$fitted,NormSM30cm$fitted,col="blue",xlab="Precip",ylab="30cm Soil Moisture",
     main=c(paste('Cor=',round(cor(NormPrecip$fitted,NormSM30cm$fitted,use="complete.obs"),2),", r^2=",round(summary(lm2)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm2, col="red", lwd=1)
lm3<-lm(NormSM50cm$fitted ~ NormPrecip$fitted)
plot(NormPrecip$fitted,NormSM50cm$fitted,col="blue",xlab="Precip",ylab="50cm Soil Moisture",
     main=c(paste('Cor=',round(cor(NormPrecip$fitted,NormSM50cm$fitted,use="complete.obs"),2),", r^2=",round(summary(lm3)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm3, col="red", lwd=1)

cor.test(NormPrecip$fitted,NormSM10cm$fitted,use="complete.obs")



# Forecasting via Lag Correlations
# Correlation Previous Months Precipitation With Current Month Soil Moisture
# VARIABLES
d<-ForecastMonth$MoAvg_SM30cm #Select soil moisture data
f<-5  #Frequencyy/time scale or window
m1<-3 #Precip month to correlate with Soil Moisture month
m2<-5 #Soil Moisture month that is being predicted

NormPrecip<-spi(ts(ForecastMonth$MoSum_Precip,freq=12,start=c(1979,1)),f,distribution = 'Gamma', fit = "ub-pwm") # changed to max-lik on 2/26/18
dum1<-fitSCI(d,first.mon=1,time.scale=1,distr="genlog",p0=FALSE,start.fun.fix=TRUE)
dum2<-transformSCI(d,first.mon=1,obj=dum1,sci.limit=3)
NormSM<-data.frame(fitted=dum2)
IndexCorr<-data.frame(ForecastMonth$Date3,ForecastMonth$Month,NormPrecip$fitted,NormSM$fitted)
colnames(IndexCorr)<-c("Date1","Month","NormPrecip","NormSM")
IndexCorr<-IndexCorr[-c(1:12,469:478),] #Remove First and last year becuase R


# Create new data frame with Precip Month (LC1) to Correlate With Soil Moisture (LC2) 
LC1<-filter(IndexCorr, IndexCorr$Month==m1)
LC2<-filter(IndexCorr, IndexCorr$Month==m2)
LagCorr<-data.frame(LC1$Month,LC1$NormPrecip,LC2$NormSM)
colnames(LagCorr)<-c("Month","NormPrecip","NormSM")

# ########## IF want to know if previous winter precip impacting spring soil moisture, need to shift precip time series
# ########## !!!!!!! ONLY DO SHIFT IF LOOKING AT MONTHS FROM PREVIOUS YEAR ie DEC -> JUNE IMPACTING NEXT YEARS MAY !!!!!!!!
# ########## UNCOMMENT WHEN NEEDED
# shift <- function(x, lag) {
#   n <- length(x)
#   xnew <- rep(NA, n)
#   if (lag < 0) {
#     xnew[1:(n-abs(lag))] <- x[(abs(lag)+1):n]
#   } else if (lag > 0) {
#     xnew[(lag+1):n] <- x[1:(n-lag)]
#   } else {
#     xnew <- x
#   }
#   return(xnew)
# }
# LagCorr$NormPrecip<-shift(LagCorr$NormPrecip,1)
# LagCorr<-LagCorr[-c(1),]
# ########## END OF SHIFT CODE; Do Not Always Run!!!
# ########## UNCOMMENT WHEN NEEDED

# Plot Lag Correlations
par(mfrow=c(1,1))
lm1<-lm(LagCorr$NormSM ~ LagCorr$NormPrecip)
plot(LagCorr$NormPrecip,LagCorr$NormSM,xlim=c(-3,3),ylim=c(-3,3),xlab="Norm Precip",ylab="Norm Soil Moisture",
     main=c("3 Month March Precip Correlated With May Soil Moisture",
     paste('Cor=',round(cor(LagCorr$NormPrecip,LagCorr$NormSM),2),", r^2=",round(summary(lm1)$r.squared,3))),cex.main=1.3)
abline(0,1)
abline(lm1, col="red", lwd=1)

cor.test(LagCorr$NormPrecip,LagCorr$NormSM)
